let a = 12;
if(a%4==0){
console.log("Yes");

} else {
console.log("no")
}