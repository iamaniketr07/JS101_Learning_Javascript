let num = 15;

if(num%3==0){
  console.log("multiple by 3" )
}