let register_email = "imaniketr07@gmail.com";
let register_password = "9876543";

let enter_email="imaniketr07@gmail.com";
let enter_password="9876543";

if(enter_email==register_email){
  
  if(enter_password==register_password){
    
    console.log("Login Successfull");
    
  } else {
    
    console.log("Incorrect Password");
  }
}