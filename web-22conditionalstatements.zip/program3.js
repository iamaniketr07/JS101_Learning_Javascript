let a = 30;
let b = 30;

if(a > b){
  console.log(a," is bigger than ",b);
  } else if(a < b){
  console.log(b,"is bigger than",a);
  } else {
  console.log("Both are equal");
}