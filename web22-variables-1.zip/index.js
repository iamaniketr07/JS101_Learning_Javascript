let name = "MASAI SCHOOL";

console.log(name);

let name2 = "A Transformation in Education";

console.log(name2);
