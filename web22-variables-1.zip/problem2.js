const name = "Aniket Raut";

console.log(typeof(name));

let char = 22

console.log(typeof(char))