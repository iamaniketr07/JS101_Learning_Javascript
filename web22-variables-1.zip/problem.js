let aniket = 75;

console.log(aniket);

var rajaram = 87

console.log(rajaram)

const ranjana = 92

console.log(ranjana)